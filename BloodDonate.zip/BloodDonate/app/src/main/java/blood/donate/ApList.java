package blood.donate;

/**
 * Created by admin on 15-10-2016.
 */
public class ApList {

    String id_ap,name_ap,address_ap,call_ap,msg_ap,grp_ap;

    public String getId_ap() {
        return id_ap;
    }

    public void setId_ap(String id_ap) {
        this.id_ap = id_ap;
    }

    public String getName_ap() {
        return name_ap;
    }

    public void setName_ap(String name_ap) {
        this.name_ap = name_ap;
    }

    public String getAddress_ap() {
        return address_ap;
    }

    public void setAddress_ap(String address_ap) {
        this.address_ap = address_ap;
    }

    public String getCall_ap() {
        return call_ap;
    }

    public void setCall_ap(String call_ap) {
        this.call_ap = call_ap;
    }

    public String getMsg_ap() {
        return msg_ap;
    }

    public void setMsg_ap(String msg_ap) {
        this.msg_ap = msg_ap;
    }

    public String getGrp_ap() {
        return grp_ap;
    }

    public void setGrp_ap(String grp_ap) {
        this.grp_ap = grp_ap;
    }

}
