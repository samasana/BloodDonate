package blood.donate;

/**
 * Created by admin on 28-09-2016.
 */
public class Constans {

    public static String PREF = "pref";
    public static String USERNAME = "UserName";
    public static String HINT = "hint";
    public static String BLOOD_GROUP = "blood_group";

}
