package blood.donate.Activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import blood.donate.R;

public class AboutUsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
    }
}
